function FridgeMenu () {

}

export default FridgeMenu