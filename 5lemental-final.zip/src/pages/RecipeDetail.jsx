import IngredientItem from '@/components/IngredientItem';

function RecipeDetail() {
  return (
    <>
      <IngredientItem />
    </>
  );
}

export default RecipeDetail;
