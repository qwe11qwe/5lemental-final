import SearchInput from "@/components/SearchInput"

function Search () {
  return(
    <SearchInput searchType='cook'/>
  )
}

export default Search